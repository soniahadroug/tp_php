<?php

$newArray = [
    1,11,2,3,22,4
];

sort($newArray);
