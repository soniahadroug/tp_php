<?php

$administration =  'cnrps';
$name = 'aymen';