<?php
/*
$date = getdate();

print_r($date);
*/
echo date("l jS \of F Y h:i:s A");